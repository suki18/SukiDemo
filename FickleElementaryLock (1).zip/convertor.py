def lbs_to_kg(weight):
  return weight/2.2046


def kg_to_lbs(weight):
  return weight * 2.2046


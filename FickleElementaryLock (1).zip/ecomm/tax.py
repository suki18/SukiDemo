def calcu_tax():
  print("Calculating tax.....")